<h1>Instructions for Setting up the Environment and run the code</h1>
<h2>step 0:</h2>
Clone the Repo.
<h2>step 1:</h2>
<p>in git VS Code Terminal/powershell, write the command: cd backend</p>
<p>in git VS Code Terminal/powershell, write the command: node server.js</p>

<h2>step 2:</h2>
Open a new terminal
<p>in git VS Code Terminal/powershell, write the command: cd frontend</p>
<p>in git VS Code Terminal/powershell, write the command: npx serve .</p>
